/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ADMIN
 */
public class Chicken {
    double weight;
    double gSapce;
    double wSapce;
    double aSpace;

    public Chicken(double weight, double gSapce, double wSapce, double aSpace) {
        this.weight = weight;
        this.gSapce = gSapce;
        this.wSapce = wSapce;
        this.aSpace = aSpace;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getgSapce() {
        return gSapce;
    }

    public void setgSapce(double gSapce) {
        this.gSapce = gSapce;
    }

    public double getwSapce() {
        return wSapce;
    }

    public void setwSapce(double wSapce) {
        this.wSapce = wSapce;
    }

    public double getaSpace() {
        return aSpace;
    }

    public void setaSpace(double aSpace) {
        this.aSpace = aSpace;
    }

   
}
