/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ADMIN
 */
public class Pig {
    double weight;
    double gSpace;

    public Pig(double weight, double gSpace) {
        this.weight = weight;
        this.gSpace = gSpace;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getgSpace() {
        return gSpace;
    }

    public void setgSpace(double gSpace) {
        this.gSpace = gSpace;
    }
}
