/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ADMIN
 */
public class Dog {
    double weight;
    double gSapce;

    public Dog(double weight, double gSapce) {
        this.weight = weight;
        this.gSapce = gSapce;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getgSapce() {
        return gSapce;
    }

    public void setgSapce(double gSapce) {
        this.gSapce = gSapce;
    }
}
