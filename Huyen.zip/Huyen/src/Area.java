/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ADMIN
 */
public class Area {
    double aSpace;
    double gSpace;
    double wSpace;

    public Area(double aSpace, double gSpace, double wSpace) {
        this.aSpace = aSpace;
        this.gSpace = gSpace;
        this.wSpace = wSpace;
    }

    public double getaSpace() {
        return aSpace;
    }

    public void setaSpace(double aSpace) {
        this.aSpace = aSpace;
    }

    public double getgSpace() {
        return gSpace;
    }

    public void setgSpace(double gSpace) {
        this.gSpace = gSpace;
    }

    public double getwSpace() {
        return wSpace;
    }

    public void setwSpace(double wSpace) {
        this.wSpace = wSpace;
    }
    
}
